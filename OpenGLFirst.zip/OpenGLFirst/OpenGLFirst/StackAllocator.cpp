#include "StackAllocator.h"
#include <assert.h>
#include <iostream>


void* top;
void* start;

StackAllocator::StackAllocator(size_t stackSize_bytes) {
	top = (void*)malloc(stackSize_bytes);
	start = top;
	//	top = (int*)calloc(stackSize_bytes, 1); //allocates and then clears stuff
	std::cout << "void top has value of " << top << " is located at " << static_cast<void*>(&top) << " and is " << sizeof(top) << " bytes" << std::endl;

	std::cout << "void start has value of " << start << " is located at " << static_cast<void*>(&start) << " and is " << sizeof(start) << " bytes" << std::endl;


}

void* StackAllocator::allocate(size_t size_bytes) {
	void* newItem = top;
	top = static_cast<char*>(top) + size_bytes;
	std::cout << "void newItem has value of " << newItem << " is located at " << static_cast<void*>(&newItem) << " and is " << sizeof(newItem) << " bytes" << std::endl;

	std::cout << "void top has value of " << top << " is located at " << static_cast<void*>(&top) << " and is " << sizeof(top) << " bytes" << std::endl;

	return newItem;


}

//void* allocateAligned(size_t size_bytes, size_t alignment) {
//	assert(alignment >= 1);
//	assert(alignment <= 128);
//	assert((alignment & (alignment - 1)) == 0); // pwr of 2
//
//	size_t expandedSize_bytes = size_bytes + alignment;
//
//	uintptr_t rawAddress = reinterpret_cast<uintptr_t>(StackAllocator::allocate(expandedSize_bytes));
//
//	size_t mask = (alignment - 1);
//	uintptr_t misalignment = (rawAddress & mask);
//	ptrdiff_t adjustment = alignment - misalignment;
//
//	uintptr_t alignedAddress = rawAddress + adjustment;
//	assert(adjustment < 256);
//	std::uint8_t* pAlignedMem = reinterpret_cast<uint8_t*>(alignedAddress);
//	pAlignedMem[-1] = static_cast<uint8_t>(adjustment);
//
//	return static_cast<void*>(pAlignedMem);
//}

void* deallocate(void* pRawMem) {
	return top;
}


void deallocateAligned(void* pMem) {
	const std::uint8_t* pAlignedMem = reinterpret_cast<const std::uint8_t*>(pMem);

	uintptr_t alignedAddress = reinterpret_cast<uintptr_t>(pMem);
	ptrdiff_t adjustment = static_cast<ptrdiff_t>(pAlignedMem[-1]);

	uintptr_t rawAddress = alignedAddress - adjustment;
	void* pRawMem = reinterpret_cast<void*>(rawAddress);

	deallocate(pRawMem);
}


void clear() {
	top = start;
}