#ifndef VECTOR
#define VECTOR

#include <math.h>
#include <xmmintrin.h>

struct Vector
{
	float v_Elements[4];
	Vector();
	Vector(float x, float y, float z, float w);


	inline Vector& operator+=(const Vector& rhs)
	{
		for (int idx = 0; idx < 4; idx++)
		{
			v_Elements[idx] += rhs.v_Elements[idx];
		}
		return *this;
	}

	inline Vector& operator-=(const Vector& rhs)
	{
		for (int idx = 0; idx < 4; idx++)
		{
			v_Elements[idx] -= rhs.v_Elements[idx];
		}
		return *this;
	}

	inline Vector& operator*=(const Vector& rhs)
	{
		v_Elements[0] = v_Elements[0] * rhs.v_Elements[0] + v_Elements[1] * rhs.v_Elements[4] + v_Elements[2] * rhs.v_Elements[8] + v_Elements[3] * rhs.v_Elements[12];
		v_Elements[1] = v_Elements[0] * rhs.v_Elements[1] + v_Elements[1] * rhs.v_Elements[5] + v_Elements[2] * rhs.v_Elements[9] + v_Elements[3] * rhs.v_Elements[13];
		v_Elements[2] = v_Elements[0] * rhs.v_Elements[2] + v_Elements[1] * rhs.v_Elements[6] + v_Elements[2] * rhs.v_Elements[10] + v_Elements[3] * rhs.v_Elements[14];
		v_Elements[3] = v_Elements[0] * rhs.v_Elements[3] + v_Elements[1] * rhs.v_Elements[7] + v_Elements[2] * rhs.v_Elements[11] + v_Elements[3] * rhs.v_Elements[15];

		v_Elements[4] = v_Elements[4] * rhs.v_Elements[0] + v_Elements[5] * rhs.v_Elements[4] + v_Elements[6] * rhs.v_Elements[8] + v_Elements[7] * rhs.v_Elements[12];
		v_Elements[5] = v_Elements[4] * rhs.v_Elements[1] + v_Elements[5] * rhs.v_Elements[5] + v_Elements[6] * rhs.v_Elements[9] + v_Elements[7] * rhs.v_Elements[13];
		v_Elements[6] = v_Elements[4] * rhs.v_Elements[2] + v_Elements[5] * rhs.v_Elements[6] + v_Elements[6] * rhs.v_Elements[10] + v_Elements[7] * rhs.v_Elements[14];
		v_Elements[7] = v_Elements[4] * rhs.v_Elements[3] + v_Elements[5] * rhs.v_Elements[7] + v_Elements[6] * rhs.v_Elements[11] + v_Elements[7] * rhs.v_Elements[15];

		v_Elements[8] = v_Elements[8] * rhs.v_Elements[0] + v_Elements[9] * rhs.v_Elements[4] + v_Elements[10] * rhs.v_Elements[8] + v_Elements[11] * rhs.v_Elements[12];
		v_Elements[9] = v_Elements[8] * rhs.v_Elements[1] + v_Elements[9] * rhs.v_Elements[5] + v_Elements[10] * rhs.v_Elements[9] + v_Elements[11] * rhs.v_Elements[13];
		v_Elements[10] = v_Elements[8] * rhs.v_Elements[2] + v_Elements[9] * rhs.v_Elements[6] + v_Elements[10] * rhs.v_Elements[10] + v_Elements[11] * rhs.v_Elements[14];
		v_Elements[11] = v_Elements[8] * rhs.v_Elements[3] + v_Elements[9] * rhs.v_Elements[7] + v_Elements[10] * rhs.v_Elements[11] + v_Elements[11] * rhs.v_Elements[15];

		v_Elements[12] = v_Elements[12] * rhs.v_Elements[0] + v_Elements[13] * rhs.v_Elements[4] + v_Elements[14] * rhs.v_Elements[8] + v_Elements[15] * rhs.v_Elements[12];
		v_Elements[13] = v_Elements[12] * rhs.v_Elements[1] + v_Elements[13] * rhs.v_Elements[5] + v_Elements[14] * rhs.v_Elements[9] + v_Elements[15] * rhs.v_Elements[13];
		v_Elements[14] = v_Elements[12] * rhs.v_Elements[2] + v_Elements[13] * rhs.v_Elements[6] + v_Elements[14] * rhs.v_Elements[10] + v_Elements[15] * rhs.v_Elements[14];
		v_Elements[15] = v_Elements[12] * rhs.v_Elements[3] + v_Elements[13] * rhs.v_Elements[7] + v_Elements[14] * rhs.v_Elements[11] + v_Elements[15] * rhs.v_Elements[15];
		return *this;
	}

	inline Vector& operator*=(const float& rhs)
	{
		for (int idx = 0; idx < 16; idx++)
		{
			v_Elements[idx] *= rhs;
		}
		return *this;
	}

	static void print(const Vector& v);

	static __m128 addWithIntrinsics(const __m128 a, const __m128 b);
};

extern inline Vector operator+(const Vector lhs, const Vector rhs);
extern inline Vector operator-(const Vector& lhs, const Vector& rhs);
extern inline Vector operator*(const Vector& lhs, const Vector& rhs);
extern inline Vector operator*(const Vector& lhs, const float& rhs);



#endif