#pragma once
#ifndef MATRIX
#define MATRIX

#include <math.h>
#include "Vector.h"
#include <xmmintrin.h>
#include <pmmintrin.h>

struct Matrix {
	float m_Elements[16];

	Matrix();
	Matrix(int scalar);

	static Matrix ScaleMatrix(Vector scaleVector);


	static Matrix TranslationMatrix(const float& xScale, const float& yScale, const float& zScale);

	static Matrix RotationMatrix(float xRot, float yRot, float zRot);

	static Vector mulVectorMatrix(Vector v, Matrix m);
	inline Matrix& operator += (const Matrix& rhs) {
		for (int idx = 0; idx < 16; idx++)
		{
			m_Elements[idx] += rhs.m_Elements[idx];
		}

		return *this;
	}

	inline Matrix& operator-=(const Matrix& rhs)
	{
		for (int idx = 0; idx < 16; idx++)
		{
			this->m_Elements[idx] -= rhs.m_Elements[idx];
		}
		return *this;
	}

	inline Matrix& operator*=(const Matrix& rhs)
	{
		m_Elements[0] = m_Elements[0] * rhs.m_Elements[0] + m_Elements[1] * rhs.m_Elements[4] + m_Elements[2] * rhs.m_Elements[8] + m_Elements[3] * rhs.m_Elements[12];
		m_Elements[1] = m_Elements[0] * rhs.m_Elements[1] + m_Elements[1] * rhs.m_Elements[5] + m_Elements[2] * rhs.m_Elements[9] + m_Elements[3] * rhs.m_Elements[13];
		m_Elements[2] = m_Elements[0] * rhs.m_Elements[2] + m_Elements[1] * rhs.m_Elements[6] + m_Elements[2] * rhs.m_Elements[10] + m_Elements[3] * rhs.m_Elements[14];
		m_Elements[3] = m_Elements[0] * rhs.m_Elements[3] + m_Elements[1] * rhs.m_Elements[7] + m_Elements[2] * rhs.m_Elements[11] + m_Elements[3] * rhs.m_Elements[15];

		m_Elements[4] = m_Elements[4] * rhs.m_Elements[0] + m_Elements[5] * rhs.m_Elements[4] + m_Elements[6] * rhs.m_Elements[8] + m_Elements[7] * rhs.m_Elements[12];
		m_Elements[5] = m_Elements[4] * rhs.m_Elements[1] + m_Elements[5] * rhs.m_Elements[5] + m_Elements[6] * rhs.m_Elements[9] + m_Elements[7] * rhs.m_Elements[13];
		m_Elements[6] = m_Elements[4] * rhs.m_Elements[2] + m_Elements[5] * rhs.m_Elements[6] + m_Elements[6] * rhs.m_Elements[10] + m_Elements[7] * rhs.m_Elements[14];
		m_Elements[7] = m_Elements[4] * rhs.m_Elements[3] + m_Elements[5] * rhs.m_Elements[7] + m_Elements[6] * rhs.m_Elements[11] + m_Elements[7] * rhs.m_Elements[15];

		m_Elements[8] = m_Elements[8] * rhs.m_Elements[0] + m_Elements[9] * rhs.m_Elements[4] + m_Elements[10] * rhs.m_Elements[8] + m_Elements[11] * rhs.m_Elements[12];
		m_Elements[9] = m_Elements[8] * rhs.m_Elements[1] + m_Elements[9] * rhs.m_Elements[5] + m_Elements[10] * rhs.m_Elements[9] + m_Elements[11] * rhs.m_Elements[13];
		m_Elements[10] = m_Elements[8] * rhs.m_Elements[2] + m_Elements[9] * rhs.m_Elements[6] + m_Elements[10] * rhs.m_Elements[10] + m_Elements[11] * rhs.m_Elements[14];
		m_Elements[11] = m_Elements[8] * rhs.m_Elements[3] + m_Elements[9] * rhs.m_Elements[7] + m_Elements[10] * rhs.m_Elements[11] + m_Elements[11] * rhs.m_Elements[15];

		m_Elements[12] = m_Elements[12] * rhs.m_Elements[0] + m_Elements[13] * rhs.m_Elements[4] + m_Elements[14] * rhs.m_Elements[8] + m_Elements[15] * rhs.m_Elements[12];
		m_Elements[13] = m_Elements[12] * rhs.m_Elements[1] + m_Elements[13] * rhs.m_Elements[5] + m_Elements[14] * rhs.m_Elements[9] + m_Elements[15] * rhs.m_Elements[13];
		m_Elements[14] = m_Elements[12] * rhs.m_Elements[2] + m_Elements[13] * rhs.m_Elements[6] + m_Elements[14] * rhs.m_Elements[10] + m_Elements[15] * rhs.m_Elements[14];
		m_Elements[15] = m_Elements[12] * rhs.m_Elements[3] + m_Elements[13] * rhs.m_Elements[7] + m_Elements[14] * rhs.m_Elements[11] + m_Elements[15] * rhs.m_Elements[15];
		return *this;
	}

	inline Matrix& operator*=(const float& rhs)
	{
		for (int idx = 0; idx < 16; idx++)
		{
			this->m_Elements[idx] *= rhs;
		}
		return *this;
	}
};

extern inline Matrix operator+(const Matrix& lhs, const Matrix& rhs);
extern inline Matrix operator-(const Matrix& lhs, const Matrix& rhs);
extern inline Matrix operator*(const Matrix& lhs, const Matrix& rhs);
extern inline Matrix operator*(const Matrix& lhs, const float& rhs);

#endif