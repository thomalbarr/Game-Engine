#ifndef QUATERNION
#define QUATERNION

#include <math.h>
#include <xmmintrin.h>
#include <pmmintrin.h>
#include "Vector.h"
#include "Matrix.h"

struct Quaternion
{
	float xyzw[4];
	Quaternion();
	Quaternion(Vector v, float angle);

	static void print(Quaternion q);

	static Vector cross(const Quaternion& a, const Vector& b);

	static Vector mulQuaternion(const Quaternion& a, const Vector& v);

	static Matrix getMatrix(const Quaternion& a);

	static Quaternion inverse(const Quaternion& q);

	static Quaternion mulQuaternion(const Quaternion& a, const Quaternion& x);

	static Quaternion conjugate(const Quaternion& a);
};

extern inline Quaternion operator+(const Quaternion& a, const Quaternion& b);
extern inline Quaternion operator-(const Quaternion& lhs, const Quaternion& rhs);
extern inline Vector operator*(const Quaternion& q, const Vector& v);
extern inline Quaternion operator*(const Quaternion& lhs, const float& rhs);

#endif