#include "Vector.h"
#include <iostream>
#include <iomanip>
#include "Matrix.h"

Vector::Vector() {}

Vector::Vector(float x, float y, float z, float w)
{
	v_Elements[0] = x;  v_Elements[1] = y; v_Elements[2] = z; v_Elements[3] = w;
}



inline Vector operator+(Vector& lhs, Vector& rhs)
{
	__m128 a = _mm_set_ps(0, lhs.v_Elements[0], lhs.v_Elements[1], lhs.v_Elements[2]);
	__m128 b = _mm_set_ps(0, rhs.v_Elements[0], rhs.v_Elements[1], rhs.v_Elements[2]);
	__m128 c = Vector::addWithIntrinsics(a, b);
	Vector newVector = Vector(1, 2, 3, 4);
	return newVector;
}

inline Vector operator-(const Vector& lhs, const Vector& rhs)
{
	Vector newVector = Vector(lhs);
	newVector -= rhs;
	return newVector;
}

inline Vector operator*(const Vector& lhs, const Vector& rhs)
{
	Vector newVector = Vector(lhs);
	newVector *= rhs;
	return newVector;
}

inline Vector operator*(const Vector& lhs, const float& rhs)
{
	Vector newVector = Vector(lhs);
	newVector *= rhs;
	return newVector;
}

__m128 Vector::addWithIntrinsics(const __m128 a, const __m128 b)
{
	return _mm_add_ps(a, b);
}

void Vector::print(const Vector& v)
{
	std::cout << "The vector is: {";
	std::cout << std::fixed << std::setprecision(3) << v.v_Elements[0];
	std::cout << ", ";
	std::cout << std::fixed << std::setprecision(3) << v.v_Elements[1];
	std::cout << ", ";
	std::cout << std::fixed << std::setprecision(3) << v.v_Elements[2];
	std::cout << ", ";
	std::cout << std::fixed << std::setprecision(3) << v.v_Elements[3];
	std::cout << "}";
}

//namespace Vector
//{
//	void mulVectorMatrix(float result[3], float v[3], float a[3][3])
//	{
//		Math::mulVectorMatrix(result, v, a);
//	}
//	void mulVectorMatrix(float result[4], float v[4], float a[4][4])
//	{
//		return Math::mulVectorMatrix(result, v, a);
//	}
//	void addVector3(float result[3], float a[3], float b[3])
//	{
//		__m128 vector1 = _mm_loadu_ps(b);
//		__m128 vector2 = _mm_loadu_ps(a);
//		_mm_storeu_ps(result, _mm_add_ps(vector1, vector2));
//	}
//	void addVector4(float result[4], float a[4], float b[4])
//	{
//		__m128 vector1 = _mm_loadu_ps(b);
//		__m128 vector2 = _mm_loadu_ps(a);
//		_mm_storeu_ps(result, _mm_add_ps(vector1, vector2));
//	}
//	void dotVector3(float& result, float a[3], float b[3])
//	{
//		result = a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
//	}
//	void dotVector4(float& result, float a[4], float b[4])
//	{
//		result = a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
//	}
//	void crossVector3(float result[3], float a[3], float b[3])
//	{
//		result[0] = a[1] * b[2] - a[2] * b[1];
//		result[1] = a[2] * b[0] - a[0] * b[2];
//		result[2] = a[0] * b[1] - a[1] * b[0];
//	}
//	void magSqdVector3(float& result, float a[3])
//	{
//		result = a[0] * a[0] + a[1] * a[1] + a[2] * a[2];
//	}
//	void magSqdVector4(float& result, float a[4])
//	{
//		result = a[0] * a[0] + a[1] * a[1] + a[2] * a[2] + a[3] * a[3];
//	}
//	void magVector3(float& result, float a[3])
//	{
//		Math::Vector::magSqdVector3(result, a);
//		result = sqrt(result);
//	}
//	void magVector4(float& result, float a[4])
//	{
//		Math::Vector::magSqdVector4(result, a);
//		result = sqrt(result);
//	}
//	void scaleVector4(float result[4], float a[4], float scale)
//	{
//		__m128 vector = _mm_loadu_ps(a);
//		__m128 temp = _mm_mul_ps(vector, _mm_set1_ps(scale));
//		_mm_storeu_ps(result, temp);
//	}
//	void scaleVector3(float result[3], float a[3], float scale)
//	{
//		float temp1[4];
//		__m128 vector = _mm_loadu_ps(a);
//		__m128 temp = _mm_mul_ps(vector, _mm_set1_ps(scale));
//		_mm_storeu_ps(temp1, temp);
//		result[0] = temp1[0];
//		result[1] = temp1[1];
//		result[2] = temp1[2];
//	}
//}