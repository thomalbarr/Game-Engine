#include "Quaternion.h"
#include <iostream>
#define _USE_MATH_DEFINES
#include <math.h>

Quaternion::Quaternion() {
	xyzw[0] = 0;  xyzw[1] = 0; xyzw[2] = 0; xyzw[3] = 1;
}

Quaternion::Quaternion(Vector v, float angle) {

	angle = M_PI / 180 * angle;
	float s = sin(angle / 2);

	xyzw[0] = v.v_Elements[0] * s;
	xyzw[1] = v.v_Elements[1] * s;
	xyzw[2] = v.v_Elements[2] * s;
	xyzw[3] = cos(angle / 2);
}

void Quaternion::print(Quaternion q) {
	std::cout << "the Quaternion is: " << q.xyzw[0] << ", " << q.xyzw[1] << ", " << q.xyzw[2] << ", " << q.xyzw[3] << std::endl;
}

Vector Quaternion::cross(const Quaternion& a, const Vector& b) {
	Vector result;
	result.v_Elements[0] = a.xyzw[1] * b.v_Elements[2] - a.xyzw[2] * b.v_Elements[1];
	result.v_Elements[1] = a.xyzw[2] * b.v_Elements[0] - a.xyzw[0] * b.v_Elements[2];
	result.v_Elements[2] = a.xyzw[0] * b.v_Elements[1] - a.xyzw[1] * b.v_Elements[0];
	result.v_Elements[3] = 0;
	return result;
}

Vector Quaternion::mulQuaternion(const Quaternion& a, const Vector& v) {
	Matrix m = getMatrix(a);
	Vector result = Matrix::mulVectorMatrix(v, m);

	return result;
}

Matrix Quaternion::getMatrix(const Quaternion& a) {
	Matrix m;

	m.m_Elements[0] = roundf(1 - (2 * pow(a.xyzw[1], 2)) - (2 * pow(a.xyzw[2], 2)));
	m.m_Elements[1] = roundf(2 * a.xyzw[0] * a.xyzw[1] - 2 * a.xyzw[2] * a.xyzw[3]);
	m.m_Elements[2] = roundf(2 * a.xyzw[0] * a.xyzw[2] - 2 * a.xyzw[1] * a.xyzw[3]);
	m.m_Elements[4] = roundf(2 * a.xyzw[0] * a.xyzw[1] - 2 * a.xyzw[2] * a.xyzw[3]);
	m.m_Elements[5] = roundf(1 - (2 * pow(a.xyzw[0], 2)) - (2 * pow(a.xyzw[2], 2)));
	m.m_Elements[6] = roundf(2 * a.xyzw[1] * a.xyzw[2] - 2 * a.xyzw[0] * a.xyzw[3]);
	m.m_Elements[8] = roundf(2 * a.xyzw[0] * a.xyzw[2] - 2 * a.xyzw[1] * a.xyzw[3]);
	m.m_Elements[9] = roundf(2 * a.xyzw[1] * a.xyzw[2] - 2 * a.xyzw[0] * a.xyzw[3]);
	m.m_Elements[10] = roundf(1 - (2 * pow(a.xyzw[0], 2)) - (2 * pow(a.xyzw[1], 2)));

	return m;
}

//Got this from the web, requires SSE3 intrinsics, which is why I have included <pmmintrin.h> 
//https://stackoverflow.com/questions/18542894/how-to-multiply-two-Quaternions-with-minimal-instructions, 
//This was necessary to implement the horizontal add and sub methods, without which writing this
//function is a giant pain in the asshole, in my opinion. I tried it for like an hour...then
//promptly ran back to the SSE3 implementation.
Quaternion Quaternion::mulQuaternion(const Quaternion& a, const Quaternion& x)
{
	Quaternion result;
	__m128 xyzw = _mm_loadu_ps(x.xyzw);
	__m128 abcd = _mm_loadu_ps(a.xyzw);

	__m128 wzyx = _mm_shuffle_ps(xyzw, xyzw, _MM_SHUFFLE(0, 1, 2, 3));
	__m128 baba = _mm_shuffle_ps(abcd, abcd, _MM_SHUFFLE(0, 1, 0, 1));
	__m128 dcdc = _mm_shuffle_ps(abcd, abcd, _MM_SHUFFLE(2, 3, 2, 3));
	__m128 ZnXWY = _mm_hsub_ps(_mm_mul_ps(xyzw, baba), _mm_mul_ps(wzyx, dcdc));
	__m128 XZYnW = _mm_hadd_ps(_mm_mul_ps(xyzw, dcdc), _mm_mul_ps(wzyx, baba));
	__m128 XZWY = _mm_addsub_ps(_mm_shuffle_ps(XZYnW, ZnXWY, _MM_SHUFFLE(3, 2, 1, 0)), _mm_shuffle_ps(ZnXWY, XZYnW, _MM_SHUFFLE(2, 3, 0, 1)));
	__m128 resultSIMD = _mm_shuffle_ps(XZWY, XZWY, _MM_SHUFFLE(2, 1, 3, 0));
	_mm_storeu_ps(result.xyzw, resultSIMD);

	return result;
}
Quaternion Quaternion::conjugate(const Quaternion& a)
{
	Quaternion result;
	if (a.xyzw[0] != 0) {
		result.xyzw[0] = -a.xyzw[0];
	}
	else {
		result.xyzw[0] = 0;
	}
	if (a.xyzw[1] != 0) {
		result.xyzw[1] = -a.xyzw[1];
	}
	else {
		result.xyzw[1] = 0;
	}
	if (a.xyzw[2] != 0) {
		result.xyzw[2] = -a.xyzw[2];
	}
	else {
		result.xyzw[2] = 0;
	}
	result.xyzw[3] = a.xyzw[3];
	return result;
}

inline Vector operator*(const Quaternion& q, const Vector& v)
{
	float num = q.xyzw[0] * 2;
	float num2 = q.xyzw[1] * 2;
	float num3 = q.xyzw[2] * 2;
	float num4 = q.xyzw[0] * num;
	float num5 = q.xyzw[1] * num2;
	float num6 = q.xyzw[2] * num3;
	float num7 = q.xyzw[0] * num2;
	float num8 = q.xyzw[0] * num3;
	float num9 = q.xyzw[1] * num3;
	float num10 = q.xyzw[3] * num;
	float num11 = (q.xyzw[3]) * (num2);
	float num12 = q.xyzw[3] * num3;
	Vector result;
	result.v_Elements[0] = roundf(((1 - (num5 + num6)) * v.v_Elements[0] + (num7 - num12) * v.v_Elements[1] + (num8 + num11) * v.v_Elements[2]));
	result.v_Elements[1] = roundf(((num7 + num12) * v.v_Elements[0] + (1 - (num4 + num6)) * v.v_Elements[1] + (num9 - num10) * v.v_Elements[2]));
	result.v_Elements[2] = roundf(((num8 - num11) * v.v_Elements[0] + (num9 + num10) * v.v_Elements[1] + (1 - (num4 + num5)) * v.v_Elements[2]));
	result.v_Elements[3] = 0;
	return result;
}
