#include "gameTester.h"


GameTester::GameTester() {}
GameTester::~GameTester() {}


void GameTester::testMemory(StackAllocator stack) {
	//float some[4] = {1.5f, 0.3f, 4.2f, 8.0f};
	//std::cout << "the size of test is " << sizeof(some) << std::endl;
	int allocations = 5000;
	std::cout << "testing memory speed for " << allocations << " allocations" << std::endl;
	auto begin = Clock::now();
	for (int i = 0; i < allocations; i++)
	{
		stack.allocate(sizeof(Vector));

	}
	auto end = Clock::now();
	std::cout << "Time taken to create " << allocations << " allocations " << std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count() << " nanoseconds" << std::endl;
	std::cout << "Time taken to create " << allocations << " allocations " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count() << " microseconds" << std::endl << std::endl;


	//void* p = stack.allocateAligned(64, 2);

	//*(int*)p = 5;
	//std::cout << "void p has a value of " << *(int*)p << " is located at " << p << " and is " << sizeof(p) << " bytes" << std::endl;
	//
	//p = some;
	//std::cout << "void p has a value of " << *(float*)p << " is located at " << p << " and is " << sizeof(p) << " bytes" << std::endl;

	//void* m = stack.allocateAligned(64, 2);
	//p = some;
	//std::cout << "void m has a value of " << *(float*)m << " is located at " << m << " and is " << sizeof(m) << " bytes" << std::endl;

	//for (int i = 0; i<5; i++)
	//{
	//	/* ptr[i] and *(ptr+i) can be used interchangeably */
	//	std::cout << *((float*)p + i) << std::endl;
	//}

	//stack.deallocateAligned(p);
	//std::cout << "void p has a value of " << *(float*)p << " is located at " << p << " and is " << sizeof(p) << " bytes" << std::endl;

	//stack.clear();

	//stack.deallocateAligned(m);
	//std::cout << "void m has a value of " << *(float*)m << " is located at " << m << " and is " << sizeof(m) << " bytes" << std::endl;

}

void GameTester::test5000() {

	std::cout << "Begin vertex tests" << std::endl;
	const int vecTestSize = 5000;
	Vector vectors[vecTestSize];

	std::cout << "Creating vertices" << std::endl;
	auto begin = Clock::now();
	for (int i = 0; i < vecTestSize; i++)
	{
		//vectors[i] = Matrix();
		vectors[i] = Vector(rand() % 200 - 100, rand() % 200 - 100, rand() % 200 - 100, 0);
		//std::cout << vectors[i] << std::endl;
		//std::cout << "the vector is: " << vectors[i].elts[0] << ", " << vectors[i].elts[1] << ", " << vectors[i].elts[2] << ", " << vectors[i].elts[3] << std::endl;

	}
	auto end = Clock::now();
	std::cout << "Time taken to create " << vecTestSize << " vectors " << std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count() << " nanoseconds" << std::endl;
	std::cout << "Time taken to create " << vecTestSize << " vectors " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count() << " microseconds" << std::endl;

	std::cout << "multiplying Vectors by a rotation, scale, transformation matrix" << std::endl;

	Matrix scale = Matrix(5);
	Matrix translation = Matrix::TranslationMatrix(5, 5, 5);
	Matrix mult = scale * translation;
	Matrix rot = Matrix::RotationMatrix(0., .5, 0.);
	mult = mult * rot;
	begin = Clock::now();
	for (int i = 0; i < vecTestSize; i++)
	{
		vectors[i] = Matrix::mulVectorMatrix(vectors[i], mult);
	}
	end = Clock::now();

	std::cout << "Time taken to compute " << vecTestSize << " vector matrix multiplications is " << std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count() << " nanoseconds" << std::endl;
	std::cout << "Time taken to compute " << vecTestSize << " vector matrix multiplications is " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count() << " microseconds" << std::endl;

	std::cout << "Multiplying vectors by a Quaternion" << std::endl;
	Vector y = Vector(0, 1, 0, 0);
	Quaternion q = Quaternion(y, 90);
	begin = Clock::now();
	for (int i = 0; i < vecTestSize; i++)
	{
		vectors[i] = q * vectors[i];
	}
	end = Clock::now();

	std::cout << "Time taken to compute " << vecTestSize << " vector Quaternion multiplications is " << std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count() << " nanoseconds" << std::endl;
	std::cout << "Time taken to compute " << vecTestSize << " vector Quaternion multiplications is " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count() << " microseconds" << std::endl << std::endl;


}

void GameTester::testQuaternions() {

	std::cout << "Begin Quaternion tests" << std::endl;

	std::cout << "Multiplying a vector by one Quaternion" << std::endl;

	Vector x = Vector(1, 0, 0, 0);
	Vector y = Vector(0, 1, 0, 0);
	std::cout << "The start vector" << std::endl;
	Vector::print(x);

	Quaternion w = Quaternion(y, 90);
	Quaternion::print(w);

	Vector d = w * x;
	std::cout << "The vector after rotating 90 degrees about the y axis" << std::endl;
	Vector::print(d);

	Quaternion h = Quaternion::conjugate(w);
	Quaternion::print(h);

	d = h * d;
	std::cout << "The vector after rotating it back" << std::endl;
	Vector::print(d);
	// --------------------------------------------------------------------------------------------------
	std::cout << "Multiplying a vector by two separate Quaternions" << std::endl;

	Quaternion x90 = Quaternion(x, 90);
	Quaternion::print(x90);
	w = Quaternion(y, 90);
	Quaternion::print(w);

	d = w * x;
	std::cout << "The vector after rotating 90 degrees about the y axis" << std::endl;
	Vector::print(d);

	d = x90 * d;
	std::cout << "The vector after rotating 90 degrees about the x axis" << std::endl;
	Vector::print(d);

	h = Quaternion::conjugate(x90);
	Quaternion::print(h);

	d = h * d;
	std::cout << "The vector after undoing the x rotation of 90" << std::endl;
	Vector::print(d);

	h = Quaternion::conjugate(w);
	Quaternion::print(h);

	d = h * d;
	std::cout << "The vector after undoing the y rotation of 90" << std::endl;
	Vector::print(d);


}