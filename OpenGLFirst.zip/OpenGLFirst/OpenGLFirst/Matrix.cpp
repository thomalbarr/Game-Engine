#include "Matrix.h"


Matrix::Matrix()
{
	m_Elements[0] = 1;  m_Elements[1] = 0; m_Elements[2] = 0; m_Elements[3] = 0;
	m_Elements[4] = 0;  m_Elements[5] = 1; m_Elements[6] = 0; m_Elements[7] = 0;
	m_Elements[8] = 0;  m_Elements[9] = 0; m_Elements[10] = 1; m_Elements[11] = 0;
	m_Elements[12] = 0;  m_Elements[13] = 0; m_Elements[14] = 0; m_Elements[15] = 1;
}

Matrix::Matrix(int scalar)
{
	m_Elements[0] = scalar;  m_Elements[1] = 0; m_Elements[2] = 0; m_Elements[3] = 0;
	m_Elements[4] = 0;  m_Elements[5] = scalar; m_Elements[6] = 0; m_Elements[7] = 0;
	m_Elements[8] = 0;  m_Elements[9] = 0; m_Elements[10] = scalar; m_Elements[11] = 0;
	m_Elements[12] = 0;  m_Elements[13] = 0; m_Elements[14] = 0; m_Elements[15] = scalar;
}
Matrix Matrix::ScaleMatrix(Vector scale)
{
	Matrix newMatrix = Matrix();
	return newMatrix;
}


Matrix Matrix::TranslationMatrix(const float& xScale, const float& yScale, const float& zScale)
{
	Matrix result;
	result.m_Elements[0] = 1;  result.m_Elements[1] = 0; result.m_Elements[2] = 0; result.m_Elements[3] = xScale;
	result.m_Elements[4] = 0;  result.m_Elements[5] = 1; result.m_Elements[6] = 0; result.m_Elements[7] = yScale;
	result.m_Elements[8] = 0;  result.m_Elements[9] = 0; result.m_Elements[10] = 1; result.m_Elements[11] = zScale;
	result.m_Elements[12] = 0;  result.m_Elements[13] = 0; result.m_Elements[14] = 0; result.m_Elements[15] = 1;
	return result;
}

Matrix Matrix::RotationMatrix(const float xRot, const float yRot, const float zRot)
{
	Matrix result;
	result.m_Elements[0] = cos(zRot) + cos(yRot);   result.m_Elements[1] = -sin(zRot);				result.m_Elements[2] = sin(yRot);				result.m_Elements[3] = 0;
	result.m_Elements[4] = sin(zRot);				result.m_Elements[5] = cos(xRot) + cos(zRot);	result.m_Elements[6] = -sin(xRot);				result.m_Elements[7] = 0;
	result.m_Elements[8] = -sin(yRot);				result.m_Elements[9] = sin(xRot);				result.m_Elements[10] = cos(xRot) + cos(yRot);	result.m_Elements[11] = 0;
	result.m_Elements[12] = 0;						result.m_Elements[13] = 0;						result.m_Elements[14] = 0;						result.m_Elements[15] = 1;
	return result;
}

inline Matrix operator+(const Matrix& lhs, const Matrix& rhs)
{
	Matrix newMatrix = Matrix(lhs);
	newMatrix += rhs;
	return newMatrix;
}

inline Matrix operator-(const Matrix& lhs, const Matrix& rhs)
{
	Matrix newMatrix = Matrix(lhs);
	newMatrix -= rhs;
	return newMatrix;
}

inline Matrix operator*(const Matrix& lhs, const Matrix& rhs)
{
	Matrix newMatrix = Matrix(lhs);
	newMatrix *= rhs;
	return newMatrix;
}

inline Matrix operator*(const Matrix& lhs, const float& rhs)
{
	Matrix newMatrix = Matrix(lhs);
	newMatrix *= rhs;
	return newMatrix;
}


Vector Matrix::mulVectorMatrix(Vector v, Matrix m)
{

#define SHUFFLE_PARAM(x,y,z,w)\
	((x) | ((y) << 2 | ((z) << 4) | ((w) << 6)))
#define _mm_replicate_x_ps(v)\
	_mm_shuffle_ps((v), (v), SHUFFLE_PARAM(0, 0, 0, 0))
#define _mm_replicate_y_ps(v)\
	_mm_shuffle_ps((v), (v), SHUFFLE_PARAM(1, 1, 1, 1))
#define _mm_replicate_z_ps(v)\
	_mm_shuffle_ps((v), (v), SHUFFLE_PARAM(2, 2, 2, 2))
#define _mm_replicate_w_ps(v)\
	_mm_shuffle_ps((v), (v), SHUFFLE_PARAM(3, 3, 3, 3))
#define _mm_madd_ps(a,b,c)\
	_mm_add_ps(_mm_mul_ps((a), (b)), (c))


	Vector r = { m.m_Elements[0], m.m_Elements[1], m.m_Elements[2], m.m_Elements[3] };

	__m128 aRow0 = _mm_loadu_ps(r.v_Elements);
	for (int idx = 0; idx < 4; idx++) {
		r.v_Elements[idx] = m.m_Elements[idx + 4];
	}
	__m128 aRow1 = _mm_loadu_ps(r.v_Elements);
	for (int idx = 0; idx < 4; idx++) {
		r.v_Elements[idx] = m.m_Elements[idx + 8];
	}
	__m128 aRow2 = _mm_loadu_ps(r.v_Elements);
	for (int idx = 0; idx < 4; idx++) {
		r.v_Elements[idx] = m.m_Elements[idx + 12];
	}
	__m128 aRow3 = _mm_loadu_ps(r.v_Elements);
	__m128 vec = _mm_loadu_ps(v.v_Elements);
	__m128 temp;
	temp = _mm_mul_ps(_mm_replicate_x_ps(vec), aRow0);
	temp = _mm_madd_ps(_mm_replicate_y_ps(vec), aRow1, temp);
	temp = _mm_madd_ps(_mm_replicate_z_ps(vec), aRow2, temp);
	temp = _mm_madd_ps(_mm_replicate_w_ps(vec), aRow3, temp);

	_mm_storeu_ps(r.v_Elements, temp);
	return r;
}

//void mulVectorMatrix(float result[3], float v[3], float a[3][3])
//{
//#define SHUFFLE_PARAM(x,y,z,w)\
//	((x) | ((y) << 2 | ((z) << 4) | ((w) << 6)))
//#define _mm_replicate_x_ps(v)\
//	_mm_shuffle_ps((v), (v), SHUFFLE_PARAM(0, 0, 0, 0))
//#define _mm_replicate_y_ps(v)\
//	_mm_shuffle_ps((v), (v), SHUFFLE_PARAM(1, 1, 1, 1))
//#define _mm_replicate_z_ps(v)\
//	_mm_shuffle_ps((v), (v), SHUFFLE_PARAM(2, 2, 2, 2))
//#define _mm_madd_ps(a,b,c)\
//	_mm_add_ps(_mm_mul_ps((a), (b)), (c))
//
//	__m128 temp;
//	__m128 aRow0 = _mm_loadu_ps(a[0]);
//	__m128 aRow1 = _mm_loadu_ps(a[1]);
//	__m128 aRow2 = _mm_loadu_ps(a[2]);
//	__m128 vec = _mm_loadu_ps(v);
//	temp = _mm_mul_ps(_mm_replicate_x_ps(vec), aRow0);
//	temp = _mm_madd_ps(_mm_replicate_y_ps(vec), aRow1, temp);
//	temp = _mm_madd_ps(_mm_replicate_z_ps(vec), aRow2, temp);
//
//	_mm_storeu_ps(result, temp);
//}
//
//namespace Matrix
//{
//#define N 4
//	void mulVectorMatrix(float result[3], float v[3], float a[3][3])
//	{
//		Math::mulVectorMatrix(result, v, a);
//	}
//	void mulVectorMatrix(float result[4], float v[4], float a[4][4])
//	{
//		return Math::mulVectorMatrix(result, v, a);
//	}
//	void mul(float result[4][4], float a[4][4], float b[4][4])
//	{
//		__m128 otherRow0 = _mm_load_ps(b[0]);
//		__m128 otherRow1 = _mm_load_ps(b[1]);
//		__m128 otherRow2 = _mm_load_ps(b[2]);
//		__m128 otherRow3 = _mm_load_ps(b[3]);
//
//		__m128 newRow0 = _mm_mul_ps(otherRow0, _mm_set1_ps(a[0][0]));
//		newRow0 = _mm_add_ps(newRow0, _mm_mul_ps(otherRow1, _mm_set1_ps(a[0][1])));
//		newRow0 = _mm_add_ps(newRow0, _mm_mul_ps(otherRow2, _mm_set1_ps(a[0][2])));
//		newRow0 = _mm_add_ps(newRow0, _mm_mul_ps(otherRow3, _mm_set1_ps(a[0][3])));
//
//		__m128 newRow1 = _mm_mul_ps(otherRow0, _mm_set1_ps(a[1][0]));
//		newRow1 = _mm_add_ps(newRow1, _mm_mul_ps(otherRow1, _mm_set1_ps(a[1][1])));
//		newRow1 = _mm_add_ps(newRow1, _mm_mul_ps(otherRow2, _mm_set1_ps(a[1][2])));
//		newRow1 = _mm_add_ps(newRow1, _mm_mul_ps(otherRow3, _mm_set1_ps(a[1][3])));
//
//		__m128 newRow2 = _mm_mul_ps(otherRow0, _mm_set1_ps(a[2][0]));
//		newRow2 = _mm_add_ps(newRow2, _mm_mul_ps(otherRow1, _mm_set1_ps(a[2][1])));
//		newRow2 = _mm_add_ps(newRow2, _mm_mul_ps(otherRow2, _mm_set1_ps(a[2][2])));
//		newRow2 = _mm_add_ps(newRow2, _mm_mul_ps(otherRow3, _mm_set1_ps(a[2][3])));
//
//		__m128 newRow3 = _mm_mul_ps(otherRow0, _mm_set1_ps(a[3][0]));
//		newRow3 = _mm_add_ps(newRow3, _mm_mul_ps(otherRow1, _mm_set1_ps(a[3][1])));
//		newRow3 = _mm_add_ps(newRow3, _mm_mul_ps(otherRow2, _mm_set1_ps(a[3][2])));
//		newRow3 = _mm_add_ps(newRow3, _mm_mul_ps(otherRow3, _mm_set1_ps(a[3][3])));
//
//		_mm_storeu_ps(result[0], newRow0);
//		_mm_storeu_ps(result[1], newRow1);
//		_mm_storeu_ps(result[2], newRow2);
//		_mm_storeu_ps(result[3], newRow3);
//	}
//	void mul(float result[3][3], float a[3][3], float b[3][3])
//	{
//		__m128 otherRow0 = _mm_load_ps(b[0]);
//		__m128 otherRow1 = _mm_load_ps(b[1]);
//		__m128 otherRow2 = _mm_load_ps(b[2]);
//
//		__m128 newRow0 = _mm_mul_ps(otherRow0, _mm_set1_ps(a[0][0]));
//		newRow0 = _mm_add_ps(newRow0, _mm_mul_ps(otherRow1, _mm_set1_ps(a[0][1])));
//		newRow0 = _mm_add_ps(newRow0, _mm_mul_ps(otherRow2, _mm_set1_ps(a[0][2])));
//
//		__m128 newRow1 = _mm_mul_ps(otherRow0, _mm_set1_ps(a[1][0]));
//		newRow1 = _mm_add_ps(newRow1, _mm_mul_ps(otherRow1, _mm_set1_ps(a[1][1])));
//		newRow1 = _mm_add_ps(newRow1, _mm_mul_ps(otherRow2, _mm_set1_ps(a[1][2])));
//
//		__m128 newRow2 = _mm_mul_ps(otherRow0, _mm_set1_ps(a[2][0]));
//		newRow2 = _mm_add_ps(newRow2, _mm_mul_ps(otherRow1, _mm_set1_ps(a[2][1])));
//		newRow2 = _mm_add_ps(newRow2, _mm_mul_ps(otherRow2, _mm_set1_ps(a[2][2])));
//
//		_mm_storeu_ps(result[0], newRow0);
//		_mm_storeu_ps(result[1], newRow1);
//		_mm_storeu_ps(result[2], newRow2);
//	}
//	void add(float result[4][4], float a[4][4], float b[4][4])
//	{
//		__m128 otherRow0 = _mm_load_ps(b[0]);
//		__m128 otherRow1 = _mm_load_ps(b[1]);
//		__m128 otherRow2 = _mm_load_ps(b[2]);
//		__m128 otherRow3 = _mm_load_ps(b[3]);
//		__m128 Row0 = _mm_load_ps(a[0]);
//		__m128 Row1 = _mm_load_ps(a[1]);
//		__m128 Row2 = _mm_load_ps(a[2]);
//		__m128 Row3 = _mm_load_ps(a[3]);
//
//		__m128 newRow0 = _mm_add_ps(otherRow0, Row0);
//		__m128 newRow1 = _mm_add_ps(otherRow1, Row1);
//		__m128 newRow2 = _mm_add_ps(otherRow2, Row2);
//		__m128 newRow3 = _mm_add_ps(otherRow3, Row3);
//
//		_mm_store_ps(result[0], newRow0);
//		_mm_store_ps(result[1], newRow1);
//		_mm_store_ps(result[2], newRow2);
//		_mm_store_ps(result[3], newRow3);
//	}
//	void add(float result[3][3], float a[3][3], float b[3][3])
//	{
//		__m128 otherRow0 = _mm_load_ps(b[0]);
//		__m128 otherRow1 = _mm_load_ps(b[1]);
//		__m128 otherRow2 = _mm_load_ps(b[2]);
//		__m128 Row0 = _mm_load_ps(a[0]);
//		__m128 Row1 = _mm_load_ps(a[1]);
//		__m128 Row2 = _mm_load_ps(a[2]);
//
//		__m128 newRow0 = _mm_add_ps(otherRow0, Row0);
//		__m128 newRow1 = _mm_add_ps(otherRow1, Row1);
//		__m128 newRow2 = _mm_add_ps(otherRow2, Row2);
//
//		_mm_store_ps(result[0], newRow0);
//		_mm_store_ps(result[1], newRow1);
//		_mm_store_ps(result[2], newRow2);
//	}
//	void sub(float result[4][4], float a[4][4], float b[4][4])
//	{
//		__m128 otherRow0 = _mm_load_ps(b[0]);
//		__m128 otherRow1 = _mm_load_ps(b[1]);
//		__m128 otherRow2 = _mm_load_ps(b[2]);
//		__m128 otherRow3 = _mm_load_ps(b[3]);
//		__m128 Row0 = _mm_load_ps(a[0]);
//		__m128 Row1 = _mm_load_ps(a[1]);
//		__m128 Row2 = _mm_load_ps(a[2]);
//		__m128 Row3 = _mm_load_ps(a[3]);
//
//		__m128 newRow0 = _mm_sub_ps(otherRow0, Row0);
//		__m128 newRow1 = _mm_sub_ps(otherRow1, Row1);
//		__m128 newRow2 = _mm_sub_ps(otherRow2, Row2);
//		__m128 newRow3 = _mm_sub_ps(otherRow3, Row3);
//
//		_mm_store_ps(result[0], newRow0);
//		_mm_store_ps(result[1], newRow1);
//		_mm_store_ps(result[2], newRow2);
//		_mm_store_ps(result[3], newRow3);
//	}
//	void sub(float result[3][3], float a[3][3], float b[3][3])
//	{
//		__m128 otherRow0 = _mm_load_ps(b[0]);
//		__m128 otherRow1 = _mm_load_ps(b[1]);
//		__m128 otherRow2 = _mm_load_ps(b[2]);
//		__m128 Row0 = _mm_load_ps(a[0]);
//		__m128 Row1 = _mm_load_ps(a[1]);
//		__m128 Row2 = _mm_load_ps(a[2]);
//
//		__m128 newRow0 = _mm_sub_ps(otherRow0, Row0);
//		__m128 newRow1 = _mm_sub_ps(otherRow1, Row1);
//		__m128 newRow2 = _mm_sub_ps(otherRow2, Row2);
//
//		_mm_store_ps(result[0], newRow0);
//		_mm_store_ps(result[1], newRow1);
//		_mm_store_ps(result[2], newRow2);
//	}
//	void transpose(float result[4][4], float a[4][4])
//	{
//		float transMat[4][4];
//		for (int row = 0; row < 4; row++)
//		{
//			for (int col = 0; col < 4; col++)
//			{
//				transMat[row][col] = a[col][row];
//			}
//		}
//		__m128 transRow0 = _mm_loadu_ps(transMat[0]);
//		__m128 transRow1 = _mm_loadu_ps(transMat[1]);
//		__m128 transRow2 = _mm_loadu_ps(transMat[2]);
//		__m128 transRow3 = _mm_loadu_ps(transMat[3]);
//
//		_mm_storeu_ps(result[0], transRow0);
//		_mm_storeu_ps(result[1], transRow1);
//		_mm_storeu_ps(result[2], transRow2);
//		_mm_storeu_ps(result[3], transRow3);
//	}
//	void transpose(float result[3][3], float a[3][3])
//	{
//		float transMat[3][3];
//		for (int row = 0; row < 3; row++)
//		{
//			for (int col = 0; col < 3; col++)
//			{
//				transMat[row][col] = a[col][row];
//			}
//		}
//		__m128 transRow0 = _mm_loadu_ps(transMat[0]);
//		__m128 transRow1 = _mm_loadu_ps(transMat[1]);
//		__m128 transRow2 = _mm_loadu_ps(transMat[2]);
//
//		_mm_storeu_ps(result[0], transRow0);
//		_mm_storeu_ps(result[1], transRow1);
//		_mm_storeu_ps(result[2], transRow2);
//	}
//
//	//This section is for the inverse of a matrix (4v4).  This was taken from https://www.geeksforgeeks.org/adjoint-inverse-matrix/.
//	void getCofactor(float A[N][N], float temp[N][N], int p, int q, int n)
//	{
//		int i = 0, j = 0;
//
//		// Looping for each element of the matrix
//		for (int row = 0; row < n; row++)
//		{
//			for (int col = 0; col < n; col++)
//			{
//				//  Copying into temporary matrix only those element
//				//  which are not in given row and column
//				if (row != p && col != q)
//				{
//					temp[i][j++] = A[row][col];
//
//					// Row is filled, so increase row index and
//					// reset col index
//					if (j == n - 1)
//					{
//						j = 0;
//						i++;
//					}
//				}
//			}
//		}
//	}
//
//	float determinant(float A[N][N], int n)
//	{
//		float D = 0; // Initialize result
//
//		//  Base case : if matrix contains single element
//		if (n == 1)
//			return A[0][0];
//
//		float temp[N][N]; // To store cofactors
//
//		int sign = 1;  // To store sign multiplier
//
//		// Iterate for each element of first row
//		for (int f = 0; f < n; f++)
//		{
//			// Getting Cofactor of A[0][f]
//			getCofactor(A, temp, 0, f, n);
//			D += sign * A[0][f] * determinant(temp, n - 1);
//
//			// terms are to be added with alternate sign
//			sign = -sign;
//		}
//
//		return D;
//	}
//
//	void adjoint(float A[N][N], float adj[N][N])
//	{
//		if (N == 1)
//		{
//			adj[0][0] = 1;
//			return;
//		}
//
//		// temp is used to store cofactors of A[][]
//		int sign = 1;
//		float temp[N][N];
//
//		for (int i = 0; i < N; i++)
//		{
//			for (int j = 0; j < N; j++)
//			{
//				// Get cofactor of A[i][j]
//				getCofactor(A, temp, i, j, N);
//
//				// sign of adj[j][i] positive if sum of row
//				// and column indexes is even.
//				sign = ((i + j) % 2 == 0) ? 1 : -1;
//
//				// Interchanging rows and columns to get the
//				// transpose of the cofactor matrix
//				adj[j][i] = (sign)*(determinant(temp, N - 1));
//			}
//		}
//	}
//
//	bool inverse(float A[N][N], float inverse[N][N])
//	{
//		// Find determinant of A[][]
//		float det = determinant(A, N);
//		if (det == 0)
//		{
//			return false;
//		}
//
//		// Find adjoint
//		float adj[N][N];
//		adjoint(A, adj);
//
//		// Find Inverse using formula "inverse(A) = adj(A)/det(A)"
//		for (int i = 0; i < N; i++)
//		for (int j = 0; j < N; j++)
//			inverse[i][j] = adj[i][j] / float(det);
//
//		return true;
//	}
//}